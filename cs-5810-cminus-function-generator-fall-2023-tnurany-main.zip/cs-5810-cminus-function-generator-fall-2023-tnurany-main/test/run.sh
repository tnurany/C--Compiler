#!/bin/bash
make test_call
make test_f_noparams
make test_func_no
make test_p_noparams
make test_proc_no
make test_func2
make test_proc2
make test_swapper
make test_recurs