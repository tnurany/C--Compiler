#include <stdio.h>
void main () {
 int i,j,k,l;

	printf("%d\n",10+20);
	i=1;  k=3; l=4;
	j = i + k + l;
	printf("%d\n",j);

}
